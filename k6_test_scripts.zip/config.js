export const BASE_URL = __ENV.BASE_URL || 'https://localhost:7209/api';
export const CATEGORY_ID = __ENV.CATEGORY_ID || 'e2870eb3-94e9-4c58-96a8-1ae0cc8f5528';