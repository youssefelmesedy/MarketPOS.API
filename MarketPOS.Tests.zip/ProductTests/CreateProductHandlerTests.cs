using Xunit;
using FluentAssertions;
using System.Threading;
using System.Threading.Tasks;

public class CreateProductHandlerTests
{
    [Fact]
    public async Task Should_Return_Error_When_SalePrice_Less_Than_PurchasePrice()
    {
        // Arrange
        var command = new CreateProductCommand
        {
            Name = "TestProduct",
            PurchasePrice = 100,
            SalePrice = 90
        };

        var handler = new CreateProductCommandHandler(...); // inject mocks

        // Act
        var result = await handler.Handle(command, CancellationToken.None);

        // Assert
        result.IsSuccess.Should().BeFalse();
        result.Message.Should().Contain("Purchase price cannot exceed sale price");
    }
}