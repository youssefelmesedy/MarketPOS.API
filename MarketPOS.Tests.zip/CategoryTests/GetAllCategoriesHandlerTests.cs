using Xunit;
using FluentAssertions;
using System.Threading.Tasks;

public class GetAllCategoriesHandlerTests
{
    [Fact]
    public async Task Should_Return_Categories()
    {
        // Arrange
        var handler = new GetAllCategoriesHandler(...); // inject mocks

        // Act
        var result = await handler.Handle(new GetAllCategoriesQuery(), default);

        // Assert
        result.Should().NotBeNull();
        result.IsSuccess.Should().BeTrue();
        result.Value.Should().NotBeEmpty();
    }
}